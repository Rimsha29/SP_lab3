#include<stdio.h>
#include "myMath.h"
int main()
{
	int x,y;
	printf("Enter num1 : ");
	scanf("%d",&x);
	printf("Enter num2 : ");
	scanf("%d",&y);
	int equal = isEqual(x,y);
	
	printf ("hey! %d \n", equal);
	//printf ("Sub of %d and %d = %d ", x,y,sub);
	printf ("\n");
	return 0;
}
