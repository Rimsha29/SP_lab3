int isEqual(int x, int y)
{
	if(x == y)
	{
		return 1;
	}
	else
		return -1;
}
void swap(int x, int y)
{
	x= x + y;
	y= x - y;
	x= x - y;
	printf ("x is %d   ", x);
	printf ("y is %d   ", y);
}
