#include <stdio.h>
#include <stdlib.h>
#include "myStr.h"
int main() {
	
	
	//char arr[6]={'a','b','b','b','b','a'};
	char arr[6]={'r','i','m','s','h','a'};
	int res= isPalindrome(arr,6);
	if (res== 1 ){
		printf ("Array is palindrome");
		printf("\n");
		}
	else{
		printf ("Array is not palindrome");
		printf("\n");
	    }
	return 0;
}
