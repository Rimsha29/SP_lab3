int isPalindrome(char *arr, int size)
{
int flag=1;
if(arr[0] != arr[size-1])
{
	return -1;
}
else
{
	int i=0;
        int j= size-1;
	while(i <= size-1)
	{
		if(arr[i]==arr[j])
		 {
			i++;
			j--;
		 }
		else
		{
		flag=-1;
		break;
		}
	    
	}
	 return flag;
	
}

}
