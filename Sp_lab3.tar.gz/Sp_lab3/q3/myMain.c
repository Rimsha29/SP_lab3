#include<stdio.h>
#include "myMath.h"
#include "myStr.h"
int main()
{
	int x,y;
	printf("Enter num1 : ");
	scanf("%d",&x);
	printf("Enter num2 : ");
	scanf("%d",&y);
	int equal = isEqual(x,y);
	printf ("hey! %d \n", equal);
	//printf ("\n", x,y,equal);
	printf ("\n");
	
	
	
	//char arr[6]={'a','b','b','b','b','a'};
	char arr[6]={'r','i','m','s','h','a'};
	int res= isPalindrome(arr,6);
	if (res== 1 ){
		printf ("Array is palindrome");
		printf("\n");
		}
	else{
		printf ("Array is not palindrome");
		printf("\n");
	    }
	return 0;
}
	

